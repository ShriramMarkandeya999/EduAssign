import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { submissionApi, setSubmissionAuthHeader } from "../api/api";

// Submit a task with a GitHub link
export const submitTask = createAsyncThunk(
    "submissions/submitTask",
    async ({ taskId, githubLink }, { rejectWithValue }) => {
        setSubmissionAuthHeader(localStorage.getItem("jwt")); // Set auth header for submissionApi

        try {
            const { data } = await submissionApi.post(`/api/submissions`, {
                task_id: taskId,
                github_link: githubLink,
            });
            console.log("Submitted task:", data);
            return data;
        } catch (error) {
            console.log("Error in submitting task:", error);
            return rejectWithValue(error.response?.data?.error || "Failed to submit task");
        }
    }
);

// Fetch all submissions
export const fetchAllSubmissions = createAsyncThunk(
    "submissions/fetchAllSubmissions",
    async (_, { rejectWithValue }) => {
        setSubmissionAuthHeader(localStorage.getItem("jwt")); // Set auth header for submissionApi
        try {
            const { data } = await submissionApi.get(`/api/submissions`);
            console.log("Fetched all submissions:", data);
            return data;
        } catch (error) {
            console.log("Error in fetching submissions:", error);
            return rejectWithValue(error.response?.data?.error || "Failed to fetch submissions");
        }
    }
);

// Fetch submissions by task ID
export const fetchSubmissionsByTaskId = createAsyncThunk(
    "submissions/fetchSubmissionsByTaskId",
    async (taskId, { rejectWithValue }) => {
        setSubmissionAuthHeader(localStorage.getItem("jwt")); // Set auth header for submissionApi
        try {
            const { data } = await submissionApi.get(`/api/submissions/task/${taskId}`);
            console.log("Fetched submissions for task ID:", data);
            return data;
        } catch (error) {
            console.log("Error in fetching submissions by task ID:", error);
            return rejectWithValue(error.response?.data?.error || "Failed to fetch submissions by task ID");
        }
    }
);

// Accept or decline a submission
export const acceptDeclineSubmission = createAsyncThunk(
    "submissions/acceptDeclineSubmission",
    async ({ id, status }, { rejectWithValue }) => {
        setSubmissionAuthHeader(localStorage.getItem("jwt")); // Set auth header for submissionApi
        try {
            const { data } = await submissionApi.put(`/api/submissions/${id}?status=${status}`, {});
            console.log("Updated submission status:", data);
            return data;
        } catch (error) {
            console.log("Error in updating submission status:", error);
            return rejectWithValue(error.response?.data?.error || "Failed to update submission status");
        }
    }
);

// Slice for handling submissions state
const submissionSlice = createSlice({
    name: 'submission',
    initialState: {
        submissions: [],
        status: 'idle',
        error: null,
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(submitTask.pending, (state) => {
                state.status = 'loading';
                state.error = null;
            })
            .addCase(submitTask.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.submissions.push(action.payload);
            })
            .addCase(submitTask.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload || action.error.message;
            })
            .addCase(fetchAllSubmissions.pending, (state) => {
                state.status = 'loading';
                state.error = null;
            })
            .addCase(fetchAllSubmissions.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.submissions = action.payload;
            })
            .addCase(fetchAllSubmissions.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload || action.error.message;
            })
            .addCase(fetchSubmissionsByTaskId.pending, (state) => {
                state.status = 'loading';
                state.error = null;
            })
            .addCase(fetchSubmissionsByTaskId.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.submissions = action.payload;
            })
            .addCase(fetchSubmissionsByTaskId.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload || action.error.message;
            })
            .addCase(acceptDeclineSubmission.pending, (state) => {
                state.status = 'loading';
                state.error = null;
            })
            .addCase(acceptDeclineSubmission.fulfilled, (state, action) => {
                state.status = 'succeeded';
                const updatedSubmission = action.payload;
                state.submissions = state.submissions.map((submission) =>
                    submission.id === updatedSubmission.id ? updatedSubmission : submission
                );
            })
            .addCase(acceptDeclineSubmission.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload || action.error.message;
            });
    },
});

export default submissionSlice.reducer;
