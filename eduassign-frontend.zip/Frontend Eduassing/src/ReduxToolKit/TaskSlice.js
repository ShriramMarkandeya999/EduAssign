import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { taskApi, setTaskAuthHeader } from "../api/api";

// Fetch all tasks
export const fetchTasks = createAsyncThunk("task/fetchTasks",
    async ({ status }) => {
        setTaskAuthHeader(localStorage.getItem("jwt"));

        try {
            const { data } = await taskApi.get("/api/tasks", {
                params: { status }
            });
            console.log("fetch tasks:", data);
            return data;
        } catch (error) {
            console.log("error", error);
            throw Error(error.response.data.error);
        }
    }
);

// Fetch tasks by user
export const fetchUsersTasks = createAsyncThunk("task/fetchUsersTasks",
    async ({ status }) => {
        setTaskAuthHeader(localStorage.getItem("jwt"));

        try {
            const { data } = await taskApi.get("/api/tasks/user", {
                params: { status }
            });
            console.log("fetch users tasks:", data);
            return data;
        } catch (error) {
            console.log("error", error);
            throw Error(error.response.data.error);
        }
    }
);

// Fetch task by ID
export const fetchTasksById = createAsyncThunk("task/fetchTasksById",
    async (taskId) => {
        setTaskAuthHeader(localStorage.getItem("jwt"));

        try {
            const { data } = await taskApi.get(`/api/tasks/${taskId}`);
            console.log("fetch tasks by id:", data);
            return data;
        } catch (error) {
            console.log("error", error);
            throw Error(error.response.data.error);
        }
    }
);

// Create a new task
export const createTask = createAsyncThunk("task/createTask",
    async (taskData) => {
        setTaskAuthHeader(localStorage.getItem("jwt"));

        try {
            const { data } = await taskApi.post(`/api/tasks`, taskData);
            console.log("created task:", data);
            return data;
        } catch (error) {
            console.log("error", error);
            throw Error(error.response.data.error);
        }
    }
);

// Update a task
export const updateTask = createAsyncThunk("task/updateTask",
    async ({ id, updatedTaskData }) => {
        setTaskAuthHeader(localStorage.getItem("jwt"));

        try {
            const { data } = await taskApi.put(`/api/tasks/${id}`, updatedTaskData);
            console.log("updated task:", data);
            return data;
        } catch (error) {
            console.log("error", error);
            throw Error(error.response.data.error);
        }
    }
);

// Assign a task to a user
export const assignedTaskToUser = createAsyncThunk("task/assignedTaskToUser",
    async ({ taskId, userId }) => {
        setTaskAuthHeader(localStorage.getItem("jwt"));

        try {
            const { data } = await taskApi.put(`/api/tasks/${taskId}/user/${userId}/assigned`);
            console.log("assigned task:", data);
            return data;
        } catch (error) {
            console.log("error", error);
            throw Error(error.response.data.error);
        }
    }
);

// Delete a task
export const deleteTask = createAsyncThunk("task/deleteTask",
    async (taskId) => {
        setTaskAuthHeader(localStorage.getItem("jwt"));

        try {
            const { data } = await taskApi.delete(`/api/tasks/${taskId}`);
            console.log("task deleted successfully");
            return taskId;
        } catch (error) {
            console.log("error", error);
            throw Error(error.response.data.error);
        }
    }
);

const taskSlice = createSlice({
    name: "task",
    initialState: {
        tasks: [],
        loading: false,
        error: null,
        taskDetails: null,
        usersTask: []
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(fetchTasks.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchTasks.fulfilled, (state, action) => {
                state.loading = false;
                state.tasks = action.payload;
            })
            .addCase(fetchTasks.rejected, (state, action) => {
                state.error = action.error.message;
                state.loading = false;
            })
            .addCase(fetchUsersTasks.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchUsersTasks.fulfilled, (state, action) => {
                state.loading = false;
                state.usersTask = action.payload;
            })
            .addCase(fetchTasksById.fulfilled, (state, action) => {
                state.loading = false;
                state.taskDetails = action.payload;
            })
            .addCase(fetchUsersTasks.rejected, (state, action) => {
                state.error = action.error.message;
                state.loading = false;
            })
            .addCase(createTask.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(createTask.fulfilled, (state, action) => {
                state.loading = false;
                state.tasks.push(action.payload);
            })
            .addCase(createTask.rejected, (state, action) => {
                state.error = action.error.message;
                state.loading = false;
            })
            .addCase(updateTask.fulfilled, (state, action) => {
                const updatedTask = action.payload;
                state.loading = false;
                state.tasks = state.tasks.map((task) =>
                    task.id === updatedTask.id ? { ...task, ...updatedTask } : task
                );
            })
            .addCase(assignedTaskToUser.fulfilled, (state, action) => {
                const updatedTask = action.payload;
                state.loading = false;
                state.tasks = state.tasks.map((task) =>
                    task.id === updatedTask.id ? { ...task, ...updatedTask } : task
                );
            })
            .addCase(deleteTask.fulfilled, (state, action) => {
                state.loading = false;
                state.tasks = state.tasks.filter((task) => task.id !== action.payload);
            });
    },
});

export default taskSlice.reducer;
