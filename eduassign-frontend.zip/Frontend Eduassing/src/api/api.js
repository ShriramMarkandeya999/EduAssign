import axios from "axios";

export const BASE_URL = "http://localhost:5003";
export const TASK_SERVICE_URL = "http://localhost:5004";
export const SUBMISSION_SERVICE_URL = "http://localhost:5005";


export const api = axios.create({
    baseURL: BASE_URL,
    headers: {
        "Content-Type": "application/json"
    }
});

export const taskApi = axios.create({
    baseURL: TASK_SERVICE_URL,
    headers: {
        "Content-Type": "application/json"
    }
});

export const submissionApi = axios.create({
    baseURL: SUBMISSION_SERVICE_URL,
    headers: {
        "Content-Type": "application/json"
    }
});

export const setAuthHeader = (token, api) => {
    if (token) api.defaults.headers.common["Authorization"] = `Bearer ${token}`
    else {
        delete api.defaults.headers.common['Authorization'];
    }
};

export const setTaskAuthHeader = (token) => {
    if (token) taskApi.defaults.headers.common["Authorization"] = `Bearer ${token}`;
    else {
        delete taskApi.defaults.headers.common['Authorization'];
    }
};

export const setSubmissionAuthHeader = (token) => {
    if (token) submissionApi.defaults.headers.common["Authorization"] = `Bearer ${token}`;
    else {
        delete submissionApi.defaults.headers.common["Authorization"];
    }
};
