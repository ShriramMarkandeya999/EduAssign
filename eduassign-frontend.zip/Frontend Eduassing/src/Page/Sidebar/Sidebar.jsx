import { Avatar, Button } from '@mui/material';
import React, { useState } from 'react';
import "./Sidebar.css";
import CreateNewTaskForm from '../Task/CreateTask';
import { useLocation, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { logout } from '../../ReduxToolKit/AuthSlice';

// Define role constants
const ROLE_ADMIN = "ROLE_ADMIN";
const ROLE_CUSTOMER = "ROLE_CUSTOMER";

// Define the menu items with roles
const menu = [
    { name: "Home", value: "Home", role: [ROLE_ADMIN, ROLE_CUSTOMER] },
    { name: "ASSIGNED", value: "DONE", role: [ROLE_ADMIN] },
    { name: "DONE", value: "DONE", role: [ROLE_CUSTOMER] },
    // { name: "ASSIGNED", value: "ASSIGNED", role: [ROLE_ADMIN] },
    { name: "NOT ASSIGNED", value: "PENDING", role: [ROLE_ADMIN] },
    { name: "Create New Assignment", value: "", role: [ROLE_ADMIN] },
    { name: "Feedback", value: "NOTIFICATION", role: [ROLE_CUSTOMER] },
];

const Sidebar = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [activeMenu, setActiveMenu] = useState("DONE");
    const [openCreateTaskForm, setOpenCreateTaskForm] = useState(false);
    const { role } = useSelector((state) => {
        console.log("Current user role from Redux store:", state.auth.user.role); // Debugging role
        return state.auth.user;
    });

    const handleCloseCreateTaskForm = () => {
        setOpenCreateTaskForm(false);
    };

    const handleOpenCreateTaskModel = () => {
        setOpenCreateTaskForm(true);
    };

    const handleMenuChange = (item) => {
        const updatedParams = new URLSearchParams(location.search);

        if (item.name === "Create New Assignment") {
            handleOpenCreateTaskModel();
        } else if (item.name === "Home") {
            updatedParams.delete("filter");
            const queryString = updatedParams.toString();
            const updatedPath = queryString ? `${location.pathname}?${queryString}` : location.pathname;
            navigate(updatedPath);
        } else {
            updatedParams.set("filter", item.value);
            navigate(`${location.pathname}?${updatedParams.toString()}`);
        }
        setActiveMenu(item.name);
    };

    const handleLogout = () => {
        dispatch(logout());
    };

    return (
        <>
            <div className='card min-h-[85vh] flex flex-col justify-center fixed w-[20vw]'>
                <div className='space-y-5 h-full'>
                    <div className='flex justify-center'>
                        <Avatar
                            sx={{ width: "8rem", height: "8rem" }}
                            className='border-2 border-[#c24dd0]'
                            src='../Images/Screenshot 2024-08-09 153528.png'
                        />
                    </div>

                    {
                        menu.filter((item) => item.role.includes(role))
                            .map((item) => (
                                <p
                                    key={item.name}
                                    onClick={() => handleMenuChange(item)}
                                    className={`py-3 px-5 rounded-full text-center cursor-pointer 
                                    ${activeMenu === item.name ? "activeMenuItem" : "menuItem"}`}
                                >
                                    {item.name}
                                </p>
                            ))
                    }
                    <Button
                        onClick={handleLogout}
                        sx={{ padding: ".7rem", borderRadius: "2rem" }}
                        fullWidth
                        className='logoutButton'
                    >
                        Logout
                    </Button>
                </div>
            </div>
            <CreateNewTaskForm open={openCreateTaskForm} handleClose={handleCloseCreateTaskForm} />
        </>
    );
};

export default Sidebar;
