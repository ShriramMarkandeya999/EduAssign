import * as React from 'react';
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import { Avatar, Button, ListItemAvatar, ListItemText, ListItem, Divider, Typography } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { getUserList } from '../../ReduxToolKit/AuthSlice';
import { assignedTaskToUser } from '../../ReduxToolKit/TaskSlice';
import { useLocation } from 'react-router-dom';

const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: '80%',
    maxWidth: 600,
    bgcolor: 'background.paper',
    outline: "none",
    boxShadow: 24,
    p: 2,
    display: 'flex',
    flexDirection: 'column',
    maxHeight: '80vh',
    overflowY: 'auto'
};

export default function UserList({ handleClose, open }) {
    const dispatch = useDispatch();
    const { auth } = useSelector(store => store);
    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);
    const taskId = queryParams.get("taskId");

    React.useEffect(() => {
        dispatch(getUserList(localStorage.getItem("jwt")));
    }, [dispatch]);

    const [selectedUsers, setSelectedUsers] = React.useState([]);

    const handleSelectAll = () => {
        if (Array.isArray(auth.users)) {
            setSelectedUsers(auth.users.map(user => user.id));
        }
    };

    const handleSelectUser = (userId) => {
        setSelectedUsers(prevSelectedUsers =>
            prevSelectedUsers.includes(userId)
                ? prevSelectedUsers.filter(id => id !== userId)
                : [...prevSelectedUsers, userId]
        );
    };

    const handleAssignTasks = () => {
        selectedUsers.forEach(userId => {
            dispatch(assignedTaskToUser({ userId, taskId }));
        });
        handleClose();
    };

    const users = Array.isArray(auth.users) ? auth.users : [];

    return (
        <Modal
            open={open}
            onClose={handleClose}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
        >
            <Box sx={style}>
                <Typography variant="h6" gutterBottom>
                    Assign Tasks
                </Typography>
                <Button
                    variant="contained"
                    color="primary"
                    onClick={handleSelectAll}
                    sx={{ mb: 2 }}
                >
                    Select All
                </Button>
                {
                    users.map((item, index) => (
                        <React.Fragment key={item.id}>
                            <div className='flex items-center justify-between w-full'>
                                <div>
                                    <ListItem>
                                        <ListItemAvatar>
                                            <Avatar src={item.avatar} />
                                        </ListItemAvatar>
                                        <ListItemText
                                            primary={item.fullName}
                                        />
                                    </ListItem>
                                </div>
                                <div>
                                    <Button
                                        onClick={() => handleSelectUser(item.id)}
                                        className='customeButton'
                                    >
                                        {selectedUsers.includes(item.id) ? 'Deselect' : 'Select'}
                                    </Button>
                                </div>
                            </div>
                            {index !== users.length - 1 && <Divider variant='inset' />}
                        </React.Fragment>
                    ))
                }
                <Button
                    variant="contained"
                    color="secondary"
                    onClick={handleAssignTasks}
                    sx={{ mt: 2 }}
                >
                    Assign Task to Selected Student
                </Button>
            </Box>
        </Modal>
    );
}
