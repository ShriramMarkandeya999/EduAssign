package com.cdac.config;

public class JwtConstant {
    public static final String SECRET_KEY="dgfhjklhgfdxcgvhjjfdcgvhbjnhgfcgvhbj";
    public static final String JWT_HEADER="Authorization";
}
