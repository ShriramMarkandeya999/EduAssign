package com.cdac.task_submission_service.modal;

public enum TaskStatus {

    PENDING("PENDING"),

    Assigned("ASSIGNED"),

    DONE("DONE");

    TaskStatus(String done) {
    }
}
