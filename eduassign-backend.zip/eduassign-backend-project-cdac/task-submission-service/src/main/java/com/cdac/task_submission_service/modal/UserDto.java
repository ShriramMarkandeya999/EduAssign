package com.cdac.task_submission_service.modal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;




    
    import java.util.List;
     @Data
     @AllArgsConstructor
     @NoArgsConstructor
    public class UserDto {
    	
       
        private String password;
        private String email;
        private String role;
        private String fullName;
        
        
        private Long id;
        private String username;
        private List<String> roles;  // Or a list of permissions if you use those

        // Getters and setters

        // Example method to check if the user has a specific role
        public boolean hasRole(String role) {
            return roles.contains(role);
        }

        // Example method to check if the user has a specific permission
        public boolean hasPermission(String permission) {
            // Implement your permission logic here
            // For example, check if the user has a specific role that grants the permission
            return roles.contains(permission);  // Adjust as needed
        }

		public Long getId() {
			// TODO Auto-generated method stub
			return id;
		}
    }


